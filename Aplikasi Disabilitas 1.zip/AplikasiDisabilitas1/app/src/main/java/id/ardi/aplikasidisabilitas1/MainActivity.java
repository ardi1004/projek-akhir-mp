package id.ardi.aplikasidisabilitas1;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private TextView tvStatus;
    private Button btnSpeak;

    private SpeechRecognizer speechRecognizer;
    private TextToSpeech tts;
    private FusedLocationProviderClient fusedLocationClient;
    private SharedPreferences sharedPreferences;

    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final String PREF_NAME = "DisabilitasPrefs";
    private static final String KEY_NAME = "userName";
    private static final String FILE_NAME = "catatan.json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvStatus = findViewById(R.id.tvStatus);
        btnSpeak = findViewById(R.id.btnSpeak);

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        checkPermissions();

        // 1. Text To Speech (TTS)
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("id", "ID"));
                speak("Aplikasi siap digunakan. Tekan tombol bicara.");
            }
        });

        // 2. Speech Recognizer
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) { tvStatus.setText("Mendengarkan..."); }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() { tvStatus.setText("Memproses..."); }
            @Override public void onError(int error) {
                tvStatus.setText("Gagal mendengar. Coba lagi.");
                speak("Gagal mendengar, silakan coba lagi.");
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) {
                    String command = matches.get(0).toLowerCase();
                    tvStatus.setText("Anda berkata:\n\"" + command + "\"");
                    processCommand(command);
                }
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });

        btnSpeak.setOnClickListener(v -> startListening());
    }

    private void checkPermissions() {
        String[] permissions = {
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        };
        boolean needRequest = false;
        for (String p : permissions) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needRequest = true;
                break;
            }
        }
        if (needRequest) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }

    private void startListening() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID");
        speechRecognizer.startListening(intent);
    }

    private void speak(String text) {
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    private void processCommand(String command) {
        // 3. Geolocation
        if (command.contains("lokasi") || command.contains("cuaca") || command.contains("dimana")) {
            getLocationAndWeather();
        } 
        // 4. SharedPreferences
        else if (command.contains("simpan nama")) {
            String name = command.replace("simpan nama", "").trim();
            if (!name.isEmpty()) {
                sharedPreferences.edit().putString(KEY_NAME, name).apply();
                speak("Nama " + name + " berhasil disimpan ke preferensi.");
            } else {
                speak("Sebutkan nama yang ingin disimpan.");
            }
        } else if (command.contains("siapa saya") || command.contains("nama saya")) {
            String name = sharedPreferences.getString(KEY_NAME, "belum diketahui");
            speak("Nama anda adalah " + name);
        } 
        // 5. JSON Internal Storage
        else if (command.contains("catat") && !command.contains("baca")) {
            String note = command.replace("catat", "").trim();
            if (!note.isEmpty()) {
                saveNoteToJson(note);
                speak("Catatan berhasil disimpan.");
            } else {
                speak("Apa yang ingin dicatat?");
            }
        } else if (command.contains("baca catatan")) {
            readNotesFromJson();
        } else {
            speak("Perintah tidak dikenali.");
        }
    }

    private void getLocationAndWeather() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            speak("Izin lokasi belum diberikan.");
            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
            if (location != null) {
                try {
                    Geocoder geocoder = new Geocoder(MainActivity.this, new Locale("id", "ID"));
                    List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                    if (addresses != null && !addresses.isEmpty()) {
                        String cityName = addresses.get(0).getLocality();
                        if (cityName == null) cityName = addresses.get(0).getSubAdminArea();
                        String response = "Lokasi anda saat ini berada di sekitar " + cityName + ". Cuaca saat ini belum tersedia secara spesifik.";
                        speak(response);
                    }
                } catch (Exception e) {
                    speak("Gagal mendapatkan nama lokasi dari koordinat.");
                }
            } else {
                speak("Lokasi belum ditemukan, pastikan GPS aktif.");
            }
        });
    }

    private void saveNoteToJson(String note) {
        try {
            JSONArray jsonArray = new JSONArray();
            File file = new File(getFilesDir(), FILE_NAME);
            if (file.exists()) {
                FileInputStream fis = new FileInputStream(file);
                BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
                StringBuilder builder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    builder.append(line);
                }
                fis.close();
                if (builder.length() > 0) {
                    jsonArray = new JSONArray(builder.toString());
                }
            }
            JSONObject obj = new JSONObject();
            obj.put("note", note);
            jsonArray.put(obj);

            FileOutputStream fos = new FileOutputStream(file);
            fos.write(jsonArray.toString().getBytes());
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
            speak("Gagal menyimpan catatan.");
        }
    }

    private void readNotesFromJson() {
        try {
            File file = new File(getFilesDir(), FILE_NAME);
            if (!file.exists()) {
                speak("Anda belum memiliki catatan.");
                return;
            }
            FileInputStream fis = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                builder.append(line);
            }
            fis.close();

            JSONArray jsonArray = new JSONArray(builder.toString());
            if (jsonArray.length() == 0) {
                speak("Catatan anda kosong.");
                return;
            }
            
            StringBuilder response = new StringBuilder("Berikut adalah catatan anda: ");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                response.append(obj.getString("note")).append(". ");
            }
            tvStatus.setText(response.toString());
            speak(response.toString());
        } catch (Exception e) {
            e.printStackTrace();
            speak("Gagal membaca catatan.");
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        super.onDestroy();
    }
}